#ifndef __UBOOTDEFS_H__
#define __UBOOTDEFS_H__



#endif // __UBOOTDEFS_H__